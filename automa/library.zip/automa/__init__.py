import sys

COPYRIGHT_NOTICE = \
	"Automa Copyright (c) 2012-2014 BugFree Software. All Rights Reserved."

_PYTHON_2_7_6_HEXVERSION = 0x20706F0
_IS_64_BIT = sys.maxsize > 2 ** 32

def _get_version_info_string():
	bit = '64' if _IS_64_BIT else '32'
	major, minor, micro = sys.version_info[:3]
	return "%s bit Python version %d.%d.%d" % (bit, major, minor, micro)

if sys.hexversion != _PYTHON_2_7_6_HEXVERSION or _IS_64_BIT:
	raise ImportError(
		"Automa requires 32 bit Python version 2.7.6 to run. You are running "
		"%s. The correct version can for instance be downloaded from: "
		"https://www.python.org/ftp/python/2.7.6/python-2.7.6.msi" %
		_get_version_info_string()
	)

from . import logging
logging.initialize()