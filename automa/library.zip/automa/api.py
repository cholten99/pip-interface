# -*- coding: utf-8 -*-
# pylint: disable=C0302
"""
The automa.api module contains the implementation and API of Automa. It is
a simple Python API that makes specifying GUI automation cases as simple as
describing them to someone looking over their shoulder at a screen.

The public functions and classes of Automa are listed below. If you wish to use
Automa functions in your Python scripts you can import them from the
``automa.api`` module::

	from automa.api import *

If you wish to get an introduction to these functions, do try the interactive
tutorial in the Automa console. You can start it via the command::

	>>> start_tutorial()
"""

from automa.api_impl.application_context import get_application_context
from automa.drivers.computer_vision.two_d_regex import ConstantTwoDRegex, \
	HORIZONTALLY, VERTICALLY
from automa.util.proxies import proxy_with_attributes
from bfs.util.encoding import repr_in_stdout_encoding
from bfs_console.util.encoding import ensure_result_is_not_unicode
from bfs_console.util.hints import give_hint_on_un_escaped_backslash
from bfs.util.inspect_ import repr_args
from collections import namedtuple, OrderedDict
from copy import copy

__all__ = [
	'click', 'doubleclick', 'drag', 'find_all', 'hover', 'kill', 'press',
	'press_and_hold', 'release', 'rightclick', 'save_screenshot', 'scroll_down',
	'scroll_left', 'scroll_right',  'scroll_up', 'start', 'switch_to',
	'wait_until', 'write',
	'Application', 'Button', 'CheckBox', 'ComboBox' ,  'GUIElement', 'ListItem',
	'MenuItem', 'Point', 'RadioButton', 'Text', 'TextField', 'TreeItem',
	'Window',
	'NoWorkWindowError', 'TimeoutExpired', 'Config', 'Image', 'HORIZONTALLY',
	'VERTICALLY',
	# Keys, excluding class 'Key':
	'ENTER', 'SPACE', 'TAB', 'ESC', 'CTRL', 'ALT', 'SHIFT', 'INS', 'BKSP',
	'DEL', 'HOME', 'END', 'PGUP', 'PGDN', 'LEFT', 'DOWN', 'RIGHT', 'UP',
	'BREAK', 'PAUSE', 'PRTSC', 'SCROLLLOCK', 'LWIN', 'CAPSLOCK', 'MENU', 'RWIN',
	'F1', 'F2', 'F3', 'F4', 'F5', 'F6', 'F7', 'F8', 'F9', 'F10', 'F11', 'F12',
	'F13', 'F14', 'F15', 'F16', 'F17', 'F18', 'F19', 'F20', 'F21', 'F22', 'F23',
	'F24', 'ADD', 'SUBTRACT', 'MULTIPLY', 'DIVIDE', 'NUMPAD0', 'NUMPAD1',
	'NUMPAD2', 'NUMPAD3', 'NUMPAD4', 'NUMPAD5', 'NUMPAD6', 'NUMPAD7', 'NUMPAD8',
	'NUMPAD9', 'NUMLOCK', 'DECIMAL', 'LSHIFT', 'RSHIFT', 'LMENU', 'RMENU',
	'LCTRL', 'RCTRL', 'PRINT', 'ACCEPT', 'CONVERT', 'MODECHANGE', 'NONCONVERT',
	'FINAL', 'PROCESSKEY', 'HANGUL', 'HANJA', 'JUNJA', 'KANJI', 'APPS', 'ATTN',
	'CLEAR', 'CRSEL', 'EREOF', 'EXECUTE', 'EXSEL', 'HELP', 'OEM_CLEAR', 'PLAY',
	'PA1', 'SELECT', 'SEPARATOR', 'ZOOM'
]
# Make it possible to get all keys via `from automa.api import *`:
from automa.drivers.windows.keys import \
	ENTER, SPACE, TAB, ESC, CTRL, ALT, SHIFT, INS, BKSP, DEL, HOME, END, PGUP, \
	PGDN, LEFT, DOWN, RIGHT, UP, BREAK, PAUSE, PRTSC, SCROLLLOCK, LWIN, \
	CAPSLOCK, MENU, RWIN, F1, F2, F3, F4, F5, F6, F7, F8, F9, F10, F11, F12, \
	F13, F14, F15, F16, F17, F18, F19, F20, F21, F22, F23, F24, ADD, SUBTRACT, \
	MULTIPLY, DIVIDE, NUMPAD0, NUMPAD1, NUMPAD2, NUMPAD3, NUMPAD4, NUMPAD5, \
	NUMPAD6, NUMPAD7, NUMPAD8, NUMPAD9, NUMLOCK, DECIMAL, LSHIFT, RSHIFT, \
	LMENU, RMENU, LCTRL, RCTRL, PRINT, ACCEPT, CONVERT, MODECHANGE, NONCONVERT,\
	FINAL, PROCESSKEY, HANGUL, HANJA, JUNJA, KANJI, APPS, ATTN, CLEAR, CRSEL,\
	EREOF, EXECUTE, EXSEL, HELP, OEM_CLEAR, PLAY, PA1, SELECT, SEPARATOR, ZOOM

def start(application, *args):
	"""
	:param application: The name or path to the application to be launched.
	:type application: str
	:param \*args: Arguments to be passed to the application.

	Starts an application using the given parameters. Often, this works with
	just the name of the application, for instance::

		start("Firefox")

	Absolute paths and command line arguments can also be used. For example::

		start("c:\Tools\Eclipse\eclipse.exe", "-data", "c:\\workspace")

	When absolute paths with backslashes are used, it is recommended that the
	strings containing the backslashes be prefixed with 'r', as in::

		start(r"c:\Tools\Eclipse\eclipse.exe", "-data", r"c:\workspace")

	The reason for this is that some characters have special meaning when
	prefixed by '\\' - eg. '\\n' stands for the newline character. The 'r'
	prefix disables the special treatment.
	"""
	return _get_api_impl().start(application, *args)

def kill(application):
	"""
	:param application: The application to kill, specified by name (string) or \
a :py:class:`automa.api.Application` instance.

    Kills the given application and all windows belonging to it. For instance::

        kill("Notepad")

    You can also pass an :py:class:`Application` object as parameter. This
    is usually used to clean up after a test or automation case::

        notepad = start("Notepad")
        try:
            # Perform GUI automation...
        finally:
            kill(notepad)
	"""
	return _get_api_impl().kill(application)

def write(text, into=None):
	"""
	:param text: The text to be written.
	:type text: str
	:param into: Name or label of a text field to write into.
	:type into: str

	Types the given text into the active window of the process last started
	by :py:func:`automa.api.start`. If parameter 'into' is given, first sets the
	focus to the text field with name or label specified by this parameter.
	Common examples of 'write' are::

		write("Hello World!")
		write("test.txt", into="File name")
	"""
	_get_api_impl().write(text, into=into)

def press(*keys):
	"""
	:param \*keys: Key or comma separated list of keys to be pressed.

	Presses the given keys in sequence. To press a normal letter key such as 'a'
	simply call `press` for that character::

		press('a')

	You can also simulate the pressing of upper case characters that way::

		press('A')

	To press a special key such as ENTER look it up in the list below, then
	call `press` for it::

		press(ENTER)

	To press multiple keys at the same time, concatenate them with `+`. For
	example, to press CTRL + a, call::

		press(CTRL + 'a')

	To press multiple key combinations in sequence, separate them by commas::

		press(ALT + 'f', 's')

	**List of non-letter keys:**

	* Common keys:
		``ENTER``, ``SPACE``, ``TAB``, ``ESC``
	* Modifiers:
		``CTRL``, ``ALT``, ``SHIFT``
	* Insertion / Deletion:
		``INS``, ``BKSP``, ``DEL``, ``END``
	* Navigation:
		``HOME``, ``END``, ``PGUP``, ``PGDN``
	* Arrows:
		``LEFT``, ``DOWN``, ``RIGHT``, ``UP``
	* Other keys above the arrow keys:
		``BREAK``, ``PAUSE``, ``PRTSC``, ``SCROLLLOCK``
	* Other keys close to SPACE:
		``LWIN``, ``CAPSLOCK``, ``MENU``, ``RWIN``
	* Function keys:
		``F1``, ``F2``, ..., ``F24``
	* Numpad operations:
		``ADD``, ``SUBTRACT``, ``MULTIPLY``, ``DIVIDE``,
	* Numpad numbers:
		``NUMPAD0``, ``NUMPAD1``, ..., ``NUMPAD9``
	* Other numpad keys:
		``NUMLOCK``, ``DECIMAL``
	* Left/right variants of other keys:
		``LSHIFT``, ``RSHIFT``, ``LMENU``, ``RMENU``, ``LCTRL``, ``RCTRL``
	* IME keys:
		``ACCEPT``, ``CONVERT``, ``MODECHANGE``, ``NONCONVERT``, ``FINAL``,
		``PROCESSKEY``, ``HANGUL``, ``HANJA``, ``JUNJA``, ``KANJI``
	* Others:
		``APPS``, ``ATTN``, ``CLEAR``, ``CRSEL``, ``EREOF``, ``EXECUTE``,
		``EXSEL``, ``HELP``, ``OEM_CLEAR``, ``PLAY``, ``PA1``, ``SELECT``,
		``SEPARATOR``, ``ZOOM``
	"""
	_get_api_impl().press(*keys)

def press_and_hold(key):
	"""
	:param key: The key to be pressed. For possible values, please see \
the documentation of :py:func:`automa.api.press`.

	Presses - and holds - the given key. This can for example be used for
	zooming::

		start("Chrome")
		press_and_hold(CTRL)
		scroll_up()
		release(CTRL)

	To release the pressed key, use :py:func:`automa.api.release`.
	"""
	_get_api_impl().press_and_hold(key)

def release(key):
	"""
	:param key: The key to be released. For possible values, please see \
the documentation of :py:func:`automa.api.press`.

	Releases a key that was previously held with
	:py:func:`automa.api.press_and_hold`.
	"""
	_get_api_impl().release(key)

def click(*elements):
	"""
	:param \*elements: Comma-separated list of GUI elements, labels (strings) \
or points.

	Clicks on the given elements in sequence. Common examples are::

		click("Close")
		click("File", "Save")
		click("File", MenuItem("Save"))
		click(Button("OK"))
		click(Point(200, 300))
		click(ComboBox("File type").center + (50, 0))

	Any object with a property called 'clickable_point' of type
	:py:class:`automa.api.Point` can be passed as a parameter. The only
	exception are strings, which are automatically wrapped as :py:class:`Text`
	objects (so ``click("Close")`` is equivalent to ``click(Text("Close"))``).
	"""
	_get_api_impl().click(*elements)

def hover(*elements):
	"""
	:param \*elements: Comma-separated list of GUI elements, labels (strings) \
or points.

	Consecutively hovers the mouse cursor over the given elements. For example::

		hover("Close")
		hover(Button("OK"))
		hover("Home", "Download", "Start")
		hover("Home", MenuItem("Download"), "Start")
		hover(Point(200, 300))
		hover(ComboBox("File type").center + (50, 0))

	Any object with a property called 'clickable_point' of type
	:py:class:`automa.api.Point` can be passed as a parameter. The only
	exception are strings, which are automatically wrapped as :py:class:`Text`
	objects (so ``hover("Close")`` is equivalent to ``hover(Text("Close"))``).
	"""
	_get_api_impl().hover(*elements)

def doubleclick(element):
	"""
	:param element: A GUI element, label (string) or point.

	Performs a double-click on the given element. For example::

		doubleclick("New folder")
		doubleclick(ListItem("Directories"))
		doubleclick(Point(200, 300))
		doubleclick(TextField("File name").center - (0, 20))

	Any object with a property called 'clickable_point' of type
	:py:class:`automa.api.Point` can be passed as a parameter. The only
	exception are strings, which are automatically wrapped as :py:class:`Text`
	objects (so ``doubleclick("Automa")`` is equivalent to
	``doubleclick(Text("Automa"))``).
	"""
	_get_api_impl().doubleclick(element)

def rightclick(element, select=None, then_select=None, *finally_select):
	"""
	:param element: The GUI element, label (string) or point to right-click.
	:param select: GUI element, label (string) or point to left-click \
immediately after performing the right-click.
	:param then_select: GUI element, label (string) or point to left-click \
after clicking the ``select`` element.
	:param \*finally_select: Comma-separated list of GUI elements, labels \
(strings) and points to left-click after clicking the ``select`` and \
``then_select`` elements

	Performs a right click on the given element, optionally clicking on the
	specified sequence of context menu elements afterwards. This can for
	example be used to empty the Recycle Bin::

		rightclick("Recycle Bin", select="Empty Recycle Bin")

	Any object with a property called 'clickable_point' of type
	:py:class:`automa.api.Point` can be passed as a parameter. The only
	exception are strings, which are automatically wrapped as :py:class:`Text`
	objects (so ``rightclick("New folder")`` is equivalent to
	``rightclick(Text("New folder"))``).
	"""
	_get_api_impl().rightclick(
		element, select=select, then_select=then_select, *finally_select
	)

def drag(gui_element, to):
	"""
	:param gui_element: The GUI element to drag.
	:param to: The GUI element or Point to drag to.

	Drags the given GUI element to the given location. For example::

		drag("File", to="Folder")

	Both parameters "gui_element" and "to" can be of any type that you can
	pass to :py:func:`automa.api.click`.

	The dragging is performed by hovering the mouse cursor over "gui_element",
	pressing and holding the left mouse button, moving the mouse cursor over
	"to", and then releasing the left mouse button again.
	"""
	_get_api_impl().drag(gui_element, to)

def switch_to(window_or_application):
	"""
	:param window_or_application: The title (string) of a window on screen, a \
:py:class:`Window` object or an :py:class:`Application` object as returned by \
:py:func:`automa.api.start`.

	Switches to the given window. For example::

		switch_to("Notepad")

	This searches for a window whose title contains "Notepad", and activates it.

	You can also switch to an Application object returned by
	:py:func:`automa.api.start`::

		notepad_1 = start("Notepad")
		notepad_2 = start("Notepad")
		switch_to(notepad_1)
		write("Hello World!")
		press(CTRL + 'a', CTRL + 'c')
		switch_to(notepad_2)
		press(CTRL + 'v')

	This starts two instances of Notepad, writes "Hello World!" into the first,
	copies that text via CTRL + 'c', and pastes it into the second instance.
	"""
	_get_api_impl().switch_to(window_or_application)

def save_screenshot(png_file_path):
	"""
	:param png_file_path: The file path (string) where the screenshot should \
be saved.

	Saves a screenshot of the entire screen to the given file path. For
	instance::

		save_screenshot(r"C:\screenshot.png")
	"""
	_get_api_impl().save_screenshot(png_file_path)

def find_all(predicate):
	"""
	Lets you find all occurrences of the given GUI element predicate. For
	instance, the following statement returns a list of all buttons with label
	"Open"::

		find_all(Button("Open"))

	In a typical usage scenario, you want to pick out one of the occurrences
	returned by :py:func:`find_all`. In such cases, :py:func:`list.sort` can
	be very useful. For example, to find the leftmost "Open" button, you can
	write::

		buttons = find_all(Button("Open"))
		leftmost_button = sorted(buttons, key=lambda button: button.x)[0]
	"""
	# We want to be able to access the protected member:
	# pylint: disable=W0212
	return map(predicate.with_occurrence, predicate._find_all())
	# pylint: enable=W0212

def wait_until(condition_fn, timeout_secs=None, interval_secs=1.0):
	"""
	Waits until the given condition function evaluates to true. This is most
	commonly used to wait for a GUI element to exist::

		wait_until(Text("Update complete").exists)

	When the optional parameter ``timeout_secs`` is given and not ``None``,
	``wait_until`` raises :py:class:`TimeoutExpired` if the condition is not
	satisfied within the given number of seconds. The parameter
	``interval_secs`` specifies the number of seconds Automa waits between
	evaluating the condition function.
	"""
	_get_api_impl().wait_until(
		condition_fn, timeout_secs=timeout_secs, interval_secs=interval_secs
	)

def scroll_up(steps=1):
	"""
	Scrolls up the mouse wheel given number of steps.
	"""
	_get_api_impl().scroll_up(steps)

def scroll_down(steps=1):
	"""
	Scrolls down the mouse wheel given number of steps.
	"""
	_get_api_impl().scroll_down(steps)

def scroll_left(steps=1):
	"""
	Scrolls left the mouse wheel given number of steps.
	"""
	_get_api_impl().scroll_left(steps)

def scroll_right(steps=1):
	"""
	Scrolls right the mouse wheel given number of steps.
	"""
	_get_api_impl().scroll_right(steps)

class APIElement(object):
	def __init__(self):
		self._first_occurrence_object = None
		self._remaining_occurrences = ()
	@classmethod
	def from_occurrence(cls, occurrence):
		result = cls()
		# We want access to the protected member. It's ours anyways:
		# pylint: disable=W0212
		result._first_occurrence_object = occurrence
		# pylint: enable=W0212
		return result
	def exists(self):
		"""
		Evaluates to true if this GUI element exists.
		"""
		self._first_occurrence_object = None
		try:
			return self._first_occurrence is not None
		except LookupError:
			return False
	def with_occurrence(self, occurrence):
		result = copy(self)
		# It's OK to access the protected member as it's ours anyways:
		# pylint: disable=W0212
		result._first_occurrence_object = occurrence
		# pylint: enable=W0212
		return result
	@property
	def _first_occurrence(self):
		if not self._is_bound():
			self._remaining_occurrences = self._find_all()
			try:
				self._first_occurrence_object = \
					next(self._remaining_occurrences)
			except StopIteration:
				self._raise_not_found_error()
		return self._first_occurrence_object
	def _is_bound(self):
		return self._first_occurrence_object is not None
	def _raise_not_found_error(self):
		# Called when _find_first fails.
		raise NotImplementedError()
	def _find_all(self):
		raise NotImplementedError()

class GUIElement(APIElement):
	"""
	This class defines properties that are available for all of Automa's GUI
	elements.

	One feature that all of Automa's GUI elements support are the optional
	arguments ``below=``, ``to_right_of=``, ``above=`` and ``to_left_of=``.
	These arguments specify where a particular GUI element is to be searched
	for. For example::

		Button("OK", to_left_of="Cancel")

	This identifies the Button to the left of text "Cancel". Being able to
	restrict the search region for a GUI element like this can be useful for
	disambiguating multiple occurrences of a GUI element, especially when the
	occurrences are arranged in a table.

	Relative GUI element searches can be nested and combined arbitrarily with
	Automa's other functions. For example::

		click(Button("Open", to_right_of=TextField("File name")))

	This clicks on the button with text "Open" to the right of text field "File
	name".
	"""
	def __init__(
			self, below=None, to_right_of=None, above=None, to_left_of=None
	):
		super(GUIElement, self).__init__()
		self._below = below
		self._to_right_of = to_right_of
		self._above = above
		self._to_left_of = to_left_of
	@property
	def x(self):
		"""
		The x-coordinate of the top-left point of this GUI element.
		"""
		return self._location.left
	@property
	def y(self):
		"""
		The y-coordinate of the top-left point of this GUI element.
		"""
		return self._location.top
	@property
	def width(self):
		"""
		The width of this GUI element.
		"""
		return self._location.width
	@property
	def height(self):
		"""
		The height of this GUI element.
		"""
		return self._location.height
	@property
	def center(self):
		"""
		The center of this GUI element, as a :py:class:`automa.api.Point`.
		"""
		# Ensure we are returning an automa.api.Point:
		return Point(*self._location.center)
	@property
	def left(self):
		# Ensure we are returning an automa.api.Point:
		return Point(*self._location.west)
	@property
	def right(self):
		# Ensure we are returning an automa.api.Point:
		return Point(*self._location.east)
	@property
	def top(self):
		# Ensure we are returning an automa.api.Point:
		return Point(*self._location.north)
	@property
	def bottom(self):
		# Ensure we are returning an automa.api.Point:
		return Point(*self._location.south)
	@property
	def clickable_point(self):
		try:
			# Ensure we are returning an automa.api.Point:
			return Point(*self._first_occurrence.clickable_point)
		except AttributeError:
			return self.center
	@property
	def _location(self):
		return self._first_occurrence.location
	def _find_all(self):
		raise NotImplementedError()
	def _raise_not_found_error(self):
		raise NotImplementedError()
	def _repr(self, cls=None, *args, **kwargs):
		# Useful for subclasses.
		constructor_repr = self._repr_constructor_args(cls, *args, **kwargs)
		if self._is_bound():
			return '<%s at x=%d, y=%d>' % (constructor_repr, self.x, self.y)
		else:
			return constructor_repr
	def _repr_using_name(self, name):
		# Useful for subclasses that are identified by 'name'.
		if self._is_bound():
			args = (self._first_occurrence.text,)
		elif name is not None:
			args = (name,)
		else:
			args = ()
		return self._repr(self.__class__, *args)
	def _repr_using_label(self, name_or_label):
		# Useful for subclasses that are identified by 'name_or_label'.
		if name_or_label:
			args = (name_or_label,)
		else:
			args = ()
		return self._repr(self.__class__, *args)
	def _repr_constructor_args(self, cls=None, *args, **kwargs):
		# Useful so that sub-classes don't have to deal with below=...,
		# to_left_of=..., etc. in their __repr__.
		if cls is None:
			cls = self.__class__
		kwargs_with_region_constraints = OrderedDict(kwargs)
		if self._below is not None:
			kwargs_with_region_constraints['below'] = self._below
		if self._to_right_of is not None:
			kwargs_with_region_constraints['to_right_of'] = self._to_right_of
		if self._above is not None:
			kwargs_with_region_constraints['above'] = self._above
		if self._to_left_of is not None:
			kwargs_with_region_constraints['to_left_of'] = self._to_left_of
		return '%s(%s)' % (
			cls.__name__, repr_args(
				self.__init__, args, kwargs_with_region_constraints,
				repr_in_stdout_encoding
			)
		)
	def __eq__(self, other):
		# We need to be able to access protected members:
		# pylint: disable=W0212
		try:
			if self._is_bound():
				return self._first_occurrence_object == \
					   other._first_occurrence_object
			else:
				return self._below == other._below \
					   and self._to_right_of == other._to_right_of \
					   and self._above == other._above \
					   and self._to_left_of == other._to_left_of
		except AttributeError:
			return False
		# pylint: enable=W0212
	def __ne__(self, other):
		return not self == other

# We need class names starting with upper-case letters:
# pylint: disable=C0103
class Image(GUIElement):
	"""
	Lets you find an image on the screen. For instance::

		click(Image("save.png"))

	This searches the screen for the pattern given by "save.png" and clicks it.

	The optional parameter 'min_similarity' specifies the minimum similarity
	(as a number between 0.0 and 1.0) the image on the screen must have with
	the sought image. The default value 0.7 represents a "main similarity". A
	value of 0.9 means "very similar" and values >= 0.99 mean "extremely
	similar, with full colors and details". Below 0.99, all image comparisons
	are performed in grayscale.

	You can also use absolute paths to locate image files. For example::

		hover(Image(r"c:\\images\\button_ok.png"))

	The 'r' prefix before the first quotation mark is required when inputting
	paths containing backslashes "\\\\".

	When not using absolute paths, image files are assumed to lie in the
	current working directory. You can find out what the current working
	directory is using the following commands::

		>>> import os
		>>> os.getcwd()

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	_DEFAULT_MIN_SIMILARITY = 0.7
	# We can't help having too many arguments (7/6):
	# pylint: disable=R0913
	@give_hint_on_un_escaped_backslash(example="Image(r'C:\\dev\\name.png')")
	def __init__(
			self, image_file_path, min_similarity=_DEFAULT_MIN_SIMILARITY,
			below=None, to_right_of=None, above=None, to_left_of=None
	):
		super(Image, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.image_file_path = image_file_path
		self.min_similarity = min_similarity
		self._two_d_regex = ConstantTwoDRegex(image_file_path, min_similarity)
	# Grant access to the protected member `_two_d_regex`:
	# pylint: disable=W0212
	def followed_by(self, image, axis=HORIZONTALLY):
		"""
		Returns an ``Image`` that represents this image followed by the given
		image.

		By default, ``followed_by`` means "followed by horizontally". To
		identify an image below another image, use
		``followed_by(..., VERTICALLY)``.
		"""
		result = copy(self)
		result._two_d_regex = \
			result._two_d_regex.followed_by(image._two_d_regex, axis=axis)
		return result
	def once_or_more(self, axis=HORIZONTALLY):
		"""
		Returns an ``Image`` that matches one or more occurrences of this image
		on the screen.

		By default, ``once_or_more`` means "once or more horizontally". To
		identify one or more occurrences of an image stacked on top of each
		other, use ``once_or_more(..., VERTICALLY)``.
		"""
		result = copy(self)
		result._two_d_regex = result._two_d_regex.once_or_more(axis=axis)
		return result
	def any_times(self, axis=HORIZONTALLY):
		"""
		Returns an ``Image`` that matches zero or more occurrences of this image
		on the screen.

		By default, ``any_times`` means "any number of times horizontally". To
		identify any number of occurrences of an image stacked on top of each
		other, use ``any_times(..., VERTICALLY)``.
		"""
		result = copy(self)
		result._two_d_regex = result._two_d_regex.any_times(axis=axis)
		return result
	def maybe_once(self):
		"""
		Returns an ``Image`` that matches zero or one occurrences of this image
		on the screen.
		"""
		result = copy(self)
		result.two_d_regex = result.two_d_regex.maybe_once()
		return result
	# pylint: enable=R0913, W0212
	def __repr__(self):
		kwargs = {}
		if self.min_similarity != self._DEFAULT_MIN_SIMILARITY:
			kwargs['min_similarity'] = self.min_similarity
		return self._repr(Image, self.image_file_path, **kwargs)
	def _raise_not_found_error(self):
		raise LookupError(
			"Could not find image %r on the screen. Maybe you'd like to use"
			" a lower min_similarity? Eg.\n"
			"\tImage(%r, min_similarity=0.5)" % (
				self.image_file_path, self.image_file_path
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_image(
			self._two_d_regex, below=self._below, to_right_of=self._to_right_of,
			above=self._above, to_left_of=self._to_left_of
		)

class Text(GUIElement):
	"""
	Lets you identify any text or label. This is most useful for checking
	whether a particular text is shown on the screen::
	
		Text("Hello World!").exists()

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, value=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(Text, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self._value = value
	def __repr__(self):
		return self._repr_using_name(self._value)
	@property
	def value(self):
		"""
		Returns the current value of this Text object.
		"""
		return self._first_occurrence.text
	def _raise_not_found_error(self):
		raise LookupError(u'Could not find text: "%s".' % self._value)
	def _find_all(self):
		return _get_gui_element_finder().find_text(
			self._value, below=self._below, to_right_of=self._to_right_of,
			above=self._above, to_left_of=self._to_left_of,
		)

class TextField(GUIElement):
	"""
	Lets you identify a text field on the screen. For example::

		TextField("File name").value

	This returns the value of the "File name" text field. If it is empty, the
	empty string '' is returned.

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name_or_label=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(TextField, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name_or_label = name_or_label
	def __repr__(self):
		return self._repr_using_label(self.name_or_label)
	@property
	def value(self):
		"""
		Returns the current value of this text field. '' if there is no value.
		"""
		return self._first_occurrence.value
	def is_enabled(self):
		"""
		Returns true if this GUI element can currently be interacted with.
		"""
		return self._first_occurrence.is_enabled()
	def is_readonly(self):
		"""
		Returns true if the value of this GUI element can be modified.
		"""
		return self._first_occurrence.is_readonly()
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a text field%s.' % (
				(u' with name or label "%s"' % self.name_or_label)
				if self.name_or_label else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_text_field(
			self.name_or_label, below=self._below,
			to_right_of=self._to_right_of, above=self._above,
			to_left_of=self._to_left_of
		)

class Button(GUIElement):
	"""
	Lets you identify a button by its name and read its properties.
	An example usage of 'Button' is::

		Button("Open file").exists()

	This will look for a button with the 'Open file' label and will return
	True if found, False otherwise.

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(Button, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name = name
	def __repr__(self):
		return self._repr_using_name(self.name)
	def is_enabled(self):
		"""
		Returns true if this GUI element can currently be interacted with.
		"""
		return self._first_occurrence.is_enabled()
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a button%s.' % (
				(u' with name "%s"' % self.name) if self.name else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_button(
			self.name, below=self._below, to_right_of=self._to_right_of,
			above=self._above, to_left_of=self._to_left_of
		)

class ComboBox(GUIElement):
	"""
	Lets you identify a combo box and read its properties and options. Eg.::

		ComboBox("Language").exists()

	This looks for a combo box with label 'Language' and returns True if found,
	False otherwise.

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name_or_label=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(ComboBox, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name_or_label = name_or_label
	def __repr__(self):
		return self._repr_using_label(self.name_or_label)
	@property
	def value(self):
		"""
		Returns the value of this GUI element.
		"""
		return self._first_occurrence.value
	def is_enabled(self):
		"""
		Returns true if this GUI element can currently be interacted with.
		"""
		return self._first_occurrence.is_enabled()
	def is_readonly(self):
		"""
		Returns true if the value of this GUI element can be modified.
		"""
		return self._first_occurrence.is_readonly()
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a combo box%s.' % (
				(u' with name or label "%s"' % self.name_or_label)
				if self.name_or_label else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_combo_box(
			self.name_or_label, below=self._below,
			to_right_of=self._to_right_of, above=self._above,
			to_left_of=self._to_left_of,
		)

class CheckBox(GUIElement):
	"""
	Lets you identify a check box by its name or label and read its properties::

		CheckBox("Show Navigator").exists()

	This looks for a check box with label 'Show Navigator' and returns True if
	found, False otherwise.

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name_or_label=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(CheckBox, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name_or_label = name_or_label
	def __repr__(self):
		return self._repr_using_label(self.name_or_label)
	def is_checked(self):
		"""
		Returns true if this GUI element is checked (selected).
		"""
		return self._first_occurrence.is_checked()
	def is_enabled(self):
		"""
		Returns true if this GUI element can currently be interacted with.
		"""
		return self._first_occurrence.is_enabled()
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a check box%s.' % (
				(u' with name or label "%s"' % self.name_or_label)
				if self.name_or_label else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_check_box(
			self.name_or_label, below=self._below,
			to_right_of=self._to_right_of, above=self._above,
			to_left_of=self._to_left_of
		)

class RadioButton(GUIElement):
	"""
	Lets you identify a radio button by name or label and read its properties.
	To for instance check whether a radio button is currently selected, use::
	
		RadioButton("Option 2").is_selected()
	
	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name_or_label=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(RadioButton, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name_or_label = name_or_label
	def __repr__(self):
		return self._repr_using_label(self.name_or_label)
	def is_selected(self):
		"""
		Returns true if this radio button is selected.
		"""
		return self._first_occurrence.is_selected()
	def is_enabled(self):
		"""
		Returns true if this GUI element can currently be interacted with.
		"""
		return self._first_occurrence.is_enabled()
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a radio button%s.' % (
				(u' with name or label "%s"' % self.name_or_label)
				if self.name_or_label else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_radio_button(
			self.name_or_label, below=self._below,
			to_right_of=self._to_right_of, above=self._above,
			to_left_of=self._to_left_of
		)

class ListItem(GUIElement):
	"""
	Lets you identify a list item by its name. This is most useful for
	distinguishing GUI elements with similar labels: In a file dialog, you often
	have a tree of folders on the left, and a list of elements of the currently
	selected folder on the right. Depending on which folder is selected, it may
	happen that a folder appears both in the tree on the left and in the list on
	the right. ListItem lets you pick out the item in the list. To select the
	item from the tree, use TreeItem.

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(ListItem, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name = name
	def __repr__(self):
		return self._repr_using_name(self.name)
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a list item%s.' % (
				(u' with name "%s"' % self.name) if self.name else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_list_item(
			self.name, below=self._below, to_right_of=self._to_right_of,
			above=self._above, to_left_of=self._to_left_of
		)

class TreeItem(GUIElement):
	"""
	Lets you identify a tree item by its name. This is most useful for
	distinguishing GUI elements with similar labels: In a file dialog, you often
	have a tree of folders on the left, and a list of elements of the currently
	selected folder on the right. Depending on which folder is selected, it may
	happen that a folder appears both in the tree on the left and in the list on
	the right. TreeItem lets you pick out the item in the tree. To select the
	item from the list, use ListItem.

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(TreeItem, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name = name
	def __repr__(self):
		return self._repr_using_name(self.name)
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a tree item%s.' % (
				(u' with name "%s"' % self.name) if self.name else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_tree_item(
			self.name, below=self._below, to_right_of=self._to_right_of,
			above=self._above, to_left_of=self._to_left_of
		)

class MenuItem(GUIElement):
	"""
	Lets you identify a menu item by its name. This can be useful for
	distinguishing GUI elements with the same name. For instance, you could
	have a menu item "Close" in the "File" menu, and a button "Close". To
	distinguish between the two, you can use::

		MenuItem("Close")

	and::

		Button("Close")

	respectively.

	For an explanation of the parameters ``below``, ``to_right_of``, ``above``
	and ``to_left_of``, please see the documentation of :py:class:`GUIElement`.
	"""
	def __init__(
			self, name=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(MenuItem, self).__init__(
			below=below, to_right_of=to_right_of, above=above,
			to_left_of=to_left_of
		)
		self.name = name
	def __repr__(self):
		return self._repr_using_name(self.name)
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find a menu item%s.' % (
				(u' with name "%s"' % self.name) if self.name else ''
			)
		)
	def _find_all(self):
		return _get_gui_element_finder().find_menu_item(
			self.name, below=self._below, to_right_of=self._to_right_of,
			above=self._above, to_left_of=self._to_left_of
		)

class Application(APIElement):
	"""
	A running instance of a program. This class is returned by
	:py:func:`automa.api.start` when a program is started and can be passed
	to functions :py:func:`switch_to` and :py:func:`kill`. Eg.::

		notepad = start("Notepad")
		# Perform some actions...
		kill(notepad)

	The ``Application`` objects roughly correspond to the entries you see
	in the "Applications" tab of the Windows task manager.

	One difference between an ``Application`` and a ``Window`` is that an
	application can have any number of windows. For instance, when you press
	CTRL + s in Notepad, you get a new window (the "Save As" dialog). This
	window still belongs to the Notepad application. When you do::

		kill("Notepad")

	you kill the whole application, and thus all windows associated with
	it. This is useful for tearing down an application with possibly several
	open windows at the end of a script or test case::

		my_app = start("MyApp")
		try:
			# Perform GUI automation
		finally:
			# Ensure the application is closed no matter what state
			# the previous steps left it in:
			kill(my_app)
	"""
	def __init__(self, title=None):
		super(Application, self).__init__()
		self.search_title = title
	@property
	def title(self):
		"""
		Returns the title of this application. This is usually the title of the
		application's main window.
		"""
		return self._first_occurrence.title
	@property
	def pid(self):
		return self._first_occurrence.pid
	@property
	def main_window(self):
		"""
		Returns the main window of this application.
		"""
		return Window.from_occurrence(self._first_occurrence.main_window)
	@ensure_result_is_not_unicode
	def __repr__(self):
		title = self.title if self._is_bound() else self.search_title
		return 'Application(%s)' % (
			repr_args(self.__init__, [title], {}, repr_in_stdout_encoding)
		)
	def _raise_not_found_error(self):
		raise LookupError(
			u'Could not find an application with title "%s".' %
			self.search_title
		)
	def _find_all(self):
		return _get_gui_element_finder().find_application(self.search_title)

class Window(GUIElement):
	"""
	Lets you identify a window by its title.
	"""
	def __init__(
			self, title=None, below=None, to_right_of=None,
			above=None, to_left_of=None
	):
		super(Window, self).__init__(
			below=below, to_right_of=to_right_of,
			above=above, to_left_of=to_left_of
		)
		self.search_title = title
	@property
	def title(self):
		result = self._first_occurrence.title
		if result == 'Program Manager':
			result = 'Desktop'
		return result
	@property
	def handle(self):
		"""
		Returns the Windows Operating System handle (HWND) assigned to this
		window.
		"""
		return self._first_occurrence.handle
	def is_minimized(self):
		"""
		Returns whether this window is minimized.
		"""
		return self._first_occurrence.is_minimized()
	@ensure_result_is_not_unicode
	def __repr__(self):
		title = self.title if self._is_bound() else self.search_title
		return self._repr_constructor_args(Window, title)
	def _raise_not_found_error(self):
		raise LookupError(
			'There is no window with title matching %r. ' % self.search_title +\
			'To see which windows are available, use:\n'
			'\tfind_all(Window())'
		)
	def _find_all(self):
		return _get_gui_element_finder().find_window(
			self.search_title, below=self._below, to_right_of=self._to_right_of,
			above=self._above, to_left_of=self._to_left_of
		)

class Point(namedtuple('Point', ['x', 'y'])):
	"""
	A clickable point. To create a ``Point`` at an offset of an existing point,
	use ``+`` and ``-``::

		>>> point = Point(x=10, y=25)
		>>> point + (10, 0)
		Point(x=20, y=25)
		>>> point - (0, 10)
		Point(x=10, y=15)
	"""
	def __new__(cls, x=0, y=0):
		return cls.__bases__[0].__new__(cls, x, y)
	def __init__(self, x=0, y=0):
		self.__class__.__bases__[0].__init__(self, seq=(x, y))
	@property
	def x(self):
		"""
		The x coordinate of the point.
		"""
		return self[0]
	@property
	def y(self):
		"""
		The y coordinate of the point.
		"""
		return self[1]
	@property
	def clickable_point(self):
		return self
	def __eq__(self, other):
		return (self.x, self.y) == other
	def __ne__(self, other):
		return not self == other
	def __hash__(self):
		return self.x + 7 * self.y
	def __add__(self, (dx, dy)):
		return Point(self.x + dx, self.y + dy)
	def __radd__(self, (dx, dy)):
		return self.__add__((dx, dy))
	def __sub__(self, (dx, dy)):
		return Point(self.x - dx, self.y - dy)
	def __rsub__(self, (x, y)):
		return Point(x - self.x, y - self.y)

class NoWorkWindowError(RuntimeError):
	"""
	Automa performs all searches for GUI elements and images in the window it
	last operated with. This window is called the "work window". Work windows
	are typically registered with Automa as the result of the start(...) and
	switch_to(...) commands. If there is no work window and an operation is
	performed that requires searching for a GUI element, such as for instance
	the	command::

		>>> click("File")

	then a NoWorkWindowError is raised, asking you to start(...) or
	switch_to(...) an existing window first.
	"""
	def __init__(self, message=None):
		if message is None:
			message = \
				"This operation requires a work window to be registered with " \
				"Automa. To register an existing window, use the command " \
				"switch_to(...). To register a new window or application, " \
				"use start(...)."
		super(NoWorkWindowError, self).__init__(message)

class TimeoutExpired(RuntimeError):
	"""
	Exception raised when Automa runs into a (predictable) timeout, such as
	during execution of command :py:func:`wait_until`.
	"""
	def __init__(self, message=None):
		args = () if message is None else (message, )
		super(TimeoutExpired, self).__init__(*args)

class _ConfigImplProxy(type):
	"""
	Forwards all attribute accesses to the ConfigImpl object from the
	application context. This works around Python's limitation that static class
	attributes can't be @property's. Precisely: Config having _ConfigImplProxy
	as metaclass implies that any attribute access Config.xyz gets translated
	into the_config_impl_obj_from_appl_ctxt.xyz. This is an attribute access on
	an object instance, which can (and does) provide the attribute via a
	@property.
	"""
	def __getattribute__(cls, item, oga=object.__getattribute__):
		def get_original_attr_value():
			result = oga(cls, item)
			try:
				return result.__get__(cls, cls)
			except (AttributeError, TypeError):
				return result
		if item.startswith('__'):
			# __doc__, __dict__ etc...
			return get_original_attr_value()
		try:
			result = getattr(_get_config_impl(), item)
			if callable(result):
				try:
					result = proxy_with_attributes(
						result, __doc__=get_original_attr_value().__doc__
					)
				except AttributeError:
					pass
			return result
		except AttributeError:
			return get_original_attr_value()
	def __setattr__(cls, key, value):
		return setattr(_get_config_impl(), key, value)

# pylint: disable=W0105
class Config(object):
	"""
	This class contains Automa's run-time configuration. To modify Automa's
	behaviour, simply assign to the properties of this class. For instance::

		Config.auto_wait_enabled = False
	"""
	__metaclass__ = _ConfigImplProxy
	def __init__(self):
		raise TypeError("The 'Config' class cannot be instantiated.")
	auto_wait_enabled = True
	"""
	When auto-wait is enabled, Automa automatically waits after performing
	GUI actions, such as :py:func:`start`, :py:func:`click` or :py:func:`write`.
	The amount of time waited is calculated dynamically, using criteria such as
	the current CPU usage. This can sometimes lead to wait intervals that are
	too long. To speed up the execution of your scripts, the property
	``auto_wait_enabled`` can therefore be used to disable Automa's automatic
	wait facility.

	You can disable or enable Automa's auto-wait at any point in your script.
	For example::

		>>> Config.auto_wait_enabled = False
		>>> write("John", into="Name")
		>>> press(TAB)
		>>> write("Smith")
		>>> Config.auto_wait_enabled = True
		>>> click("Submit")

	For a way of speeding up Automa's auto-wait without completely disabling it,
	see :py:data:`automa.api.Config.wait_interval_secs`.
	"""
	search_timeout_secs = 30
	"""
	Amount of time (in seconds) Automa attempts to find a GUI element for.
	If the search does not succeed within the time defined by this configuration
	value, Automa raises :py:class:`TimeoutExpired`. Increasing the property of
	this value can be useful on lower-spec computers.
	"""
	search_max_depth = 100
	"""
	The maximum number of UI elements Automa investigates when looking for
	a given element. Increasing this value makes Automa run slower, however
	the results returned are more accurate.
	"""
	wait_interval_secs = 0.3
	"""
	Determines the minimum time (in seconds) Automa waits for actions to
	complete when :py:data:`automa.api.Config.auto_wait_enabled` is set to
	True. This configuration parameter also specifies how long Automa waits
	between every two consecutive measurements when probing an applications'
	activity to check whether the action has completed or not.

	The higher the value of this configuration parameter, the more stable but
	slower script runs become. The value must always be greater than zero.
	"""
	delay_after_mouse_move_secs = 0.01
	"""
	Determines the time (in seconds) Automa waits between moving the mouse
	and performing a mouse click when one of the commands :py:func:`click`,
	:py:func:`rightclick` and :py:func:`doubleclick` is executed. The value
	should always be strictly greater than zero to ensure stability of
	automation scripts.
	"""
	@classmethod
	def reset(cls):
		"""
		Resets the config to default values.
		"""
		_get_config_impl().reset()
# pylint: enable=W0105

def _get_api_impl():
	return get_application_context().get_object('APIImpl')

def _get_config_impl():
	return get_application_context().get_object('ConfigImpl')

def _get_gui_element_finder():
	return get_application_context().get_object('GUIElementFinder')